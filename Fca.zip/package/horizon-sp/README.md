## Lưu Ý
+ Xin Vui Lòng Không Chỉnh Sửa, Việc Chỉnh Sửa Của Bạn Chúng Tôi Sẽ Không Chịu Trách Nhiệm !
+ Nếu Bạn Phát Hiện Lỗi Hoặc Muốn Đóng Góp Ý Kiến Hay Là Nâng Cấp Code Thì Hãy Liên Hệ Với:
### Facebook.com/Lazic.Kanzu

## Info
+ Giúp Fix Lỗi FCA Install :v
+ Chả Biết Để Làm Gì Nữa :v

## P/S
+ Nó Nguy Hiểm VCL Nên Ae Cẩn Thận Nhé ehehehehheehhe